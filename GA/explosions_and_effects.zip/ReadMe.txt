
Explosion and Effects Pack 1
----------------------------
By Daniel Smith


   <<ABOUT>>

I made this a while ago, but i thought it may be usefull for some people. Perhaps some people will use these effects rather than the over-used built in effects.



   <<HOW TO USE>>

In breif, use the chosen image as a sprite for a new object, then add the event "annimation end". In this event call the action "destroy object" 


  WHAT? CAN U DUMB IT DOWN A LITTLE?
To use an explosion or effect in your game, simply extract these files then:
- Create a new object, name it "explosion" or watever you want.
- Open up the object window, and click on "new" under sprite.
- A window should pop-up, In this sprite window, click load sprite, then find the explosion image you want.
- Click ok on this sprite window
- Click add event,


  YOU CANT TELL ME WHAT TO DO!
Fine, use it any way you want.